#ifndef BST_H
#define BST_H
#include <iostream>
#include <string.h>


using std::cout;
using std::endl;
using namespace std;

/*
Author: Aditi Rai
This file contains declarations for a node class 
and the binary search tree class 
*/

template <typename T>
class BinarySearchNode
{
    private:
        T word;
        BinarySearchNode* left;
        BinarySearchNode* right;
    
    public:
        BinarySearchNode()
        {
            this->word = {};
            this->left = NULL;
            this->right = NULL;
        }

        BinarySearchNode(T wordSearch)
        {
            this->word = wordSearch;
            this->left = NULL;
            this->right = NULL;
        }

        T& getWord()
        {
            return this->word;
        }

        void setWord(T wordNode)
        {
            this->left = wordNode;
        }

        BinarySearchNode* getLeft()
        {
            return this->left;
        }

        BinarySearchNode* getRight()
        {
            return this->right;
        }

        void setLeft(BinarySearchNode* wordLeft)
        {
            this->left = wordLeft;
        }

        void setRight(BinarySearchNode* wordRight)
        {
            this->right = wordRight;
        }

};

template <typename T>
class BinaryTree
{
    private:
        BinarySearchNode<T> *root;
        //BinarySearchNode* root;
        int numElements;
        int uniqueElements;
    
    public:
        //constructor and deconstructor
        BinaryTree()
        {
            this->root = NULL;
            this->numElements = 0;
            this->uniqueElements = 0;
        }
        ~BinaryTree();

        //required functions
        BinarySearchNode<T>* insert(T insertWord)
        {
            
        /*
        BST property for our way through the tree 
        find where node belongs and hook into tree after building the node
        function returns the pointer to the newly constructed node
        if value is already in the tree, that pointer is returned instead
        */
       
            if(this->numElements > 0)
            {
                BinarySearchNode<T>* tempPtr = exists(insertWord);
                if(!tempPtr)
                {
                    this->uniqueElements++;
                }
                else
                {
                    tempPtr->getWord().incrementFrequency();
                    return NULL;
                }    
            }
            if(this->root == NULL)
            {
                //insert into empty tree
                this->root = new BinarySearchNode<T>(insertWord);
                this->numElements++;
                this->uniqueElements++;
                this->root->getWord().incrementFrequency();
                return this->root;
            }
            else
            {
                //node that walks the tree
                BinarySearchNode<T>* walk = this->root;
                bool keepWalking = true;

                while(keepWalking)
                {
                    keepWalking = false;

                    if(insertWord == walk->getWord())
                    {
                        return walk;
                    }
                    else if(insertWord < walk->getWord())
                    {
                        //smaller goes left
                        if(walk->getLeft() != NULL)
                        {
                            walk = walk->getLeft();
                            keepWalking = true;
                        }
                        else
                        {
                            //found place, build and hook in new node
                            BinarySearchNode<T>* tempPtr = new BinarySearchNode<T>(insertWord);
                            walk->setLeft(tempPtr);
                            this->numElements++;
                            tempPtr->getWord().incrementFrequency();
                            return tempPtr;
                        }
                    }
                    else
                    {
                        if(walk->getRight() != NULL)
                        {
                            walk = walk->getRight();
                            keepWalking = true;
                        }
                        else
                        {
                            //found place in right node
                            
                            walk->setRight(new BinarySearchNode<T>(insertWord));
                            this->numElements++;
                            return walk->getRight();
                        }
                    }
                }
            }


            return NULL;
        } //end of insert function declaration 

        BinarySearchNode<T>* find(T word)
        {
            return this->findHelper(word, this->root);
        }

        bool remove(T removeWord)
        {
            if(this->root == NULL)
            {
                return false;
            }

            BinarySearchNode<T>* remove = this->root;
            BinarySearchNode<T>* parent;

            while( (remove != NULL) && (remove->getWord() != removeWord))
            {
                if(removeWord < remove->getWord())
                {
                    parent = remove;
                    remove = remove->getLeft();
                }
                else
                {
                    parent = remove;
                    remove = remove->getRight();
                }
            }

            if(remove == NULL)
            {
                return false;
            }

            if( (remove->getLeft() == NULL) && (remove->getRight() == NULL) )
            {
                //no children
                if(parent->getLeft() == remove)
                {
                    parent->setLeft(NULL);
                }
                else
                {
                    parent->setRight(NULL);
                }
                delete remove;
            }
            else if( (remove->getLeft() != NULL) && (remove->getRight() != NULL) )
            {
                //2 children
                this->deleteCaseTwoChild(parent, remove);
            }
            else
            {
                //1 child
                this->deleteCaseOneChild;
                delete remove;
            }
            
            this->numElements--;
            return true;
        }

        BinarySearchNode<T>* exists(T doesExist)
        {
            BinarySearchNode<T>* result = this->findHelper(doesExist, this->root);
            if(result == NULL)
            {
                return NULL;
            }
            else
            {
                return result;
            }
        }

        void toArray(BinarySearchNode<T>* root, T* convertedarr, int &position)
        {
            if(root == NULL)
            {
                return;
            }
            toArray(root->getLeft());
            convertedarr[position] = root->getWord();
            position++;
            toArray(root->getRight());
            return;
        }

        void deleteEverything(BinarySearchNode<T>* deleting)
        {
            //use post order traversal to delete, left right middle

            if(deleting != NULL)
            {
                deleteEverything(deleting->getLeft());
                deleteEverything(deleting->getRight());
                delete deleting;
            }

            this->numElements = 0;
        }
        int howManyElements()
        {
            return this->numElements;
        }
        int howManyUnique()
        {
            return this->uniqueElements;
        }

        
        //helper functions
        //use this function for exists, find, remove
        BinarySearchNode<T>* findHelper(T word, BinarySearchNode<T>* temp)
        {
            //compare element to root, if found return pointer
            //if not, check left subtree
            //still not, check right subtree
            //repeat using recursion to traverse through entire tree
            //if not found return null

            if((temp == NULL) || (temp->getWord() == word))
            {

                return temp;
            }
            else if(word < temp->getWord())
            {
                return findHelper(word, temp->getLeft());
            }
            else if(word > temp->getWord())
            {
                return findHelper(word, temp->getRight());
            }
            else
            {
                return NULL;
            }
        }
        
        void printTreeTraversal(BinarySearchNode<T>* root)
        {
            if(root!= NULL)
            {
                printTreeTraversal(root->getLeft());
                cout<<root->getWord()<<endl;
                printTreeTraversal(root->getRight());
            }
        }

    private:
        //removing helper functions
        void deleteCaseOneChild(BinarySearchNode<T>* parent, BinarySearchNode<T>* remove)
        {
            //outer if-else statement ti determine where the one child is
            if(remove->getRight() != NULL) //remove only has a right child
            {
                //shuffle the pointers
                if(parent->getRight() == remove)
                {
                    parent->setRight(remove->getRight());
                }
                else
                {
                    parent->setLeft(remove->getRight());
                }
                
                remove->setRight(NULL);
            }
            else //remove has a left child only
            {
                //shuffle the pointers
                if(parent->getRight() == remove)
                {
                    parent->setRight(remove->getLeft());
                }
                else
                {
                    parent->setLeft(remove->getLeft());
                }

                remove->setLeft(NULL);
            }
        }
        void deleteCaseTwoChild(BinarySearchNode<T>* parent, BinarySearchNode<T>* remove)
        {
            //2 children means we need nearest predecessor, swap and then delete

            BinarySearchNode<T>* pred = remove->getLeft();
            BinarySearchNode<T>* predParent;

            //read tree from left to right

            while(pred->getRight() != NULL)
            {
                predParent = pred;
                pred = pred->getRight();
            }

            //pred variable becomes the pred now

            T temp = remove->getWord();
            remove->setWord(pred->getWord());
            pred->setWord(temp);

            //now dealing w a case with 0 children or 1 

            if((pred->getRight() != NULL) (pred->getLeft() == NULL))
            {
                //case no children 
                if(predParent->getRight() == pred)
                {
                    predParent->getRight(NULL);
                    delete pred;
                }
            }
            else
            {
                //case 1 child
                this->deleteCaseOneChild(predParent, pred);
                delete pred;
            }
            
        }

       

};

#endif