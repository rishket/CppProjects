#ifndef WORD_ENTRY_H
#define WORD_ENTRY_H

#include <iostream>
using std::string;
using namespace std;

/*
Author: Aditi Rai
word entry header file
*/



class wordEntry
{
    public:
        int frequency;
        string word;

        wordEntry();
        wordEntry(string tword);

        string getWord();
        void setWord(string read);        
        int getFrequency ();
        void incrementFrequency();

        bool operator==(const wordEntry b)
        {

            return (this->word == b.word);
        }

        bool operator<(const wordEntry b)
        {
            return (this->word < b.word);
        }

        bool operator>(const wordEntry b)
        {
            return (this->word > b.word);
        }

};

#endif